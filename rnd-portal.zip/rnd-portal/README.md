# ⚗️ College R&D Management Portal

A full-stack web application for managing and publishing academic research papers, built with **Node.js + Express** backend and vanilla **HTML/CSS/JavaScript** frontend.

---

## 🚀 Features

| Feature | Description |
|---|---|
| 🔐 Auth | JWT-based login & registration with bcrypt password hashing |
| 👥 Roles | Student, Faculty, and Admin roles with different permissions |
| 📄 Papers | Submit research papers with file upload (PDF/DOC/DOCX) |
| 🔍 Search | Filter by title, abstract, author, keywords, domain, year |
| 📊 Analytics | View-count tracking, domain distribution, researcher stats |
| 🌐 Public Access | Anyone can browse & read papers without logging in |
| 🗑️ Management | Authors and Admins can delete papers |
| ⚙️ Admin Panel | Manage all users and papers from a dedicated dashboard |

---

## 📁 Project Structure

```
rnd-portal/
├── server.js              # Main Express server (API + static serving)
├── package.json
├── data/
│   ├── users.json         # Seed users imported into MySQL if users table is empty
│   └── papers.json        # Seed papers imported into MySQL if papers table is empty
└── public/
    ├── index.html         # Home / Landing page
    ├── 404.html           # Not found page
    ├── css/
    │   └── main.css       # All styles
    ├── js/
    │   └── app.js         # Shared utilities & auth helpers
    ├── pages/
    │   ├── login.html     # Login page
    │   ├── register.html  # Registration page
    │   ├── papers.html    # Browse all papers (with search/filter)
    │   ├── paper-detail.html  # Single paper view
    │   ├── dashboard.html # User dashboard (submit, my papers)
    │   └── stats.html     # Portal statistics & analytics
    └── uploads/           # Uploaded paper files (auto-created)
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Node.js v16+ 
- npm
- MySQL Server

### Steps

```bash
# 1. Navigate to the project folder
cd rnd-portal

# 2. Install dependencies
npm install

# 3. Configure MySQL if your settings differ from the defaults
# Defaults: DB_HOST=localhost, DB_PORT=3306, DB_USER=root, DB_PASSWORD=, DB_NAME=rnd_portal

# 4. Start the server
npm start
# OR
node server.js

# 5. Open in browser
# http://localhost:3000
```

On startup, the server creates the `rnd_portal` database and required tables if they do not exist. If the `users` or `papers` tables are empty, existing seed data from `data/users.json` and `data/papers.json` is imported automatically.

---

## 🔑 Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@college.edu | admin123 |
| Faculty | priya.sharma@college.edu | faculty123 |
| Faculty | rajesh.kumar@college.edu | faculty123 |
| Student | ananya.patel@college.edu | student123 |
| Student | rohan.mehta@college.edu | student123 |

---

## 🌐 Pages

| URL | Description |
|---|---|
| `/` | Home / Landing page with hero, features, recent papers |
| `/pages/papers.html` | Browse all papers with live search & filters |
| `/pages/paper-detail.html?id=<id>` | View a single research paper |
| `/pages/login.html` | Login |
| `/pages/register.html` | Register as Student or Faculty |
| `/pages/dashboard.html` | User dashboard — submit papers, view own papers |
| `/pages/stats.html` | Institution-wide analytics |

---

## 📡 API Endpoints

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/register` | Create new account |
| POST | `/api/login` | Login and get JWT token |
| GET | `/api/me` | Get current user (auth required) |

### Papers
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/papers` | List all papers (supports `?search=`, `?domain=`, `?year=`) |
| GET | `/api/papers/:id` | Get single paper (increments view count) |
| POST | `/api/papers` | Submit new paper with optional file upload (auth required) |
| DELETE | `/api/papers/:id` | Delete paper (owner or admin only) |

### Stats & Admin
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/stats` | Portal statistics (public) |
| GET | `/api/users` | List all users (admin only) |

---

## 🛠️ Tech Stack

- **Backend**: Node.js, Express.js
- **Auth**: JSON Web Tokens (JWT), bcryptjs
- **File Upload**: Multer
- **Database**: MySQL via `mysql2`
- **Frontend**: Vanilla HTML5, CSS3, JavaScript (ES6+)
- **Fonts**: Google Fonts (Inter, Playfair Display)

---

## 📝 Notes

- Papers and users are stored in MySQL. The JSON files in `data/` are only used as seed/import data when tables are empty
- Configure database access with `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, and `DB_NAME`
- Configure `JWT_SECRET` with an environment variable for production
- Uploaded files are stored in `public/uploads/`
- JWT secret is in `server.js` — move to `.env` for production

---

*Built for academic excellence 🎓*
