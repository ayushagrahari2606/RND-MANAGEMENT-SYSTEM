// ── AUTH HELPERS ─────────────────────────────────────────────────────────────
const API = '';

function getToken() { return localStorage.getItem('rnd_token'); }
function getUser() {
  const u = localStorage.getItem('rnd_user');
  return u ? JSON.parse(u) : null;
}
function setAuth(token, user) {
  localStorage.setItem('rnd_token', token);
  localStorage.setItem('rnd_user', JSON.stringify(user));
}
function logout() {
  localStorage.removeItem('rnd_token');
  localStorage.removeItem('rnd_user');
  window.location.href = '/';
}
function authHeaders() {
  return { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getToken()}` };
}

// ── NAVBAR STATE ──────────────────────────────────────────────────────────────
(function updateNav() {
  const user = getUser();
  const navAuth = document.getElementById('nav-auth');
  const navUser = document.getElementById('nav-user');
  if (user && navAuth && navUser) {
    navAuth.classList.add('hidden');
    navUser.classList.remove('hidden');
  }
  // Mobile
  const mobLogin = document.getElementById('mob-login');
  const mobReg = document.getElementById('mob-register');
  const mobDash = document.getElementById('mob-dashboard');
  if (user) {
    if (mobLogin) mobLogin.classList.add('hidden');
    if (mobReg) mobReg.classList.add('hidden');
    if (mobDash) mobDash.classList.remove('hidden');
  }
})();

function toggleMenu() {
  const m = document.getElementById('mobile-menu');
  if (m) m.classList.toggle('hidden');
}

// ── PAPER CARD TEMPLATE ───────────────────────────────────────────────────────
function paperCard(p) {
  const date = new Date(p.createdAt).toLocaleDateString('en-IN', { year: 'numeric', month: 'short', day: 'numeric' });
  const roleClass = `role-${p.submittedBy.role}`;
  return `
    <div class="paper-card" onclick="window.location='/pages/paper-detail.html?id=${p.id}'">
      <span class="paper-domain">${p.domain}</span>
      <div class="paper-title">${p.title}</div>
      <div class="paper-abstract">${p.abstract}</div>
      <div class="paper-meta">
        <span>👤 ${p.submittedBy.name}</span>
        <span>🏛️ ${p.submittedBy.department}</span>
        <span>👁 ${p.views || 0} views</span>
      </div>
      <div class="paper-footer">
        <span class="role-badge ${roleClass}">${p.submittedBy.role}</span>
        <span>${date}</span>
      </div>
    </div>`;
}

// ── API CALLS ─────────────────────────────────────────────────────────────────
async function apiGet(url) {
  const res = await fetch(API + url);
  return res.json();
}
async function apiPost(url, body) {
  const res = await fetch(API + url, { method: 'POST', headers: authHeaders(), body: JSON.stringify(body) });
  return res.json();
}
async function apiDelete(url) {
  const res = await fetch(API + url, { method: 'DELETE', headers: authHeaders() });
  return res.json();
}
