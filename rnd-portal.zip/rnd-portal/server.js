const express = require('express');
require('dotenv').config();
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'rnd_portal_secret_2024';

const DB_NAME = process.env.DB_NAME || 'rnd_portal';
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || ''
};

let db;

// Ensure upload/data directories exist
const DATA_DIR = path.join(__dirname, 'data');
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const USERS_FILE = path.join(DATA_DIR, 'users.json');
const PAPERS_FILE = path.join(DATA_DIR, 'papers.json');

const readJSONIfExists = (file) => {
  if (!fs.existsSync(file)) return [];
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch {
    return [];
  }
};

const toUserResponse = (user) => ({
  id: user.id,
  name: user.name,
  email: user.email,
  role: user.role,
  department: user.department
});

const toPaperResponse = (paper) => ({
  id: paper.id,
  title: paper.title,
  abstract: paper.abstract_text,
  authors: paper.authors,
  domain: paper.domain,
  keywords: paper.keywords || '',
  journal: paper.journal || '',
  submittedBy: {
    id: paper.submitted_by_id,
    name: paper.submitted_by_name,
    role: paper.submitted_by_role,
    department: paper.submitted_by_department
  },
  views: paper.views || 0,
  fileUrl: paper.file_url,
  fileName: paper.file_name,
  createdAt: paper.created_at instanceof Date ? paper.created_at.toISOString() : paper.created_at
});

const initDatabase = async () => {
  const connection = await mysql.createConnection(dbConfig);
  await connection.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await connection.end();

  db = mysql.createPool({
    ...dbConfig,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    namedPlaceholders: true
  });

  await db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(36) PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      role ENUM('student', 'faculty', 'admin') NOT NULL,
      department VARCHAR(255) NOT NULL,
      joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await db.query(`
    CREATE TABLE IF NOT EXISTS papers (
      id VARCHAR(36) PRIMARY KEY,
      title VARCHAR(500) NOT NULL,
      abstract_text TEXT NOT NULL,
      authors TEXT NOT NULL,
      keywords TEXT,
      domain VARCHAR(255) NOT NULL,
      journal VARCHAR(255),
      file_url VARCHAR(500),
      file_name VARCHAR(255),
      submitted_by_id VARCHAR(36) NOT NULL,
      submitted_by_name VARCHAR(255) NOT NULL,
      submitted_by_role VARCHAR(50) NOT NULL,
      submitted_by_department VARCHAR(255) NOT NULL,
      views INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_domain (domain),
      INDEX idx_created_at (created_at),
      INDEX idx_submitted_by_id (submitted_by_id)
    )
  `);

  await importJsonDataIfEmpty();
  await seedAdmin();
};

const importJsonDataIfEmpty = async () => {
  const [[{ count: userCount }]] = await db.query('SELECT COUNT(*) AS count FROM users');
  const [[{ count: paperCount }]] = await db.query('SELECT COUNT(*) AS count FROM papers');

  if (userCount === 0) {
    const users = readJSONIfExists(USERS_FILE);
    for (const user of users) {
      await db.query(
        `INSERT INTO users (id, name, email, password, role, department, joined_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          user.id,
          user.name,
          user.email,
          user.password,
          user.role,
          user.department,
          new Date(user.joinedAt || Date.now())
        ]
      );
    }
    if (users.length) console.log(`Imported ${users.length} users from data/users.json`);
  }

  if (paperCount === 0) {
    const papers = readJSONIfExists(PAPERS_FILE);
    for (const paper of papers) {
      await db.query(
        `INSERT INTO papers (
          id, title, abstract_text, authors, keywords, domain, journal, file_url, file_name,
          submitted_by_id, submitted_by_name, submitted_by_role, submitted_by_department,
          views, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          paper.id,
          paper.title,
          paper.abstract,
          paper.authors,
          paper.keywords || '',
          paper.domain,
          paper.journal || '',
          paper.fileUrl || null,
          paper.fileName || null,
          paper.submittedBy?.id,
          paper.submittedBy?.name,
          paper.submittedBy?.role,
          paper.submittedBy?.department,
          paper.views || 0,
          new Date(paper.createdAt || Date.now())
        ]
      );
    }
    if (papers.length) console.log(`Imported ${papers.length} papers from data/papers.json`);
  }
};

const seedAdmin = async () => {
  const [[existing]] = await db.query('SELECT id FROM users WHERE email = ?', ['admin@college.edu']);
  if (!existing) {
    const hash = await bcrypt.hash('admin123', 10);
    await db.query(
      `INSERT INTO users (id, name, email, password, role, department, joined_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [uuidv4(), 'Admin', 'admin@college.edu', hash, 'admin', 'Administration', new Date()]
    );
    console.log('Admin seeded: admin@college.edu / admin123');
  }
};

// Multer setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => cb(null, uuidv4() + path.extname(file.originalname))
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['.pdf', '.doc', '.docx'];
    if (allowed.includes(path.extname(file.originalname).toLowerCase())) cb(null, true);
    else cb(new Error('Only PDF/DOC/DOCX files allowed'));
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Auth middleware
const auth = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// AUTH ROUTES
app.post('/api/register', async (req, res) => {
  try {
    const { name, email, password, role, department } = req.body;
    if (!name || !email || !password || !role || !department) {
      return res.status(400).json({ error: 'All fields required' });
    }

    const [[existing]] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) return res.status(400).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 10);
    const user = { id: uuidv4(), name, email, password: hash, role, department };
    await db.query(
      `INSERT INTO users (id, name, email, password, role, department, joined_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [user.id, name, email, hash, role, department, new Date()]
    );

    const token = jwt.sign(toUserResponse(user), JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: toUserResponse(user) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [[user]] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign(toUserResponse(user), JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: toUserResponse(user) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/me', auth, (req, res) => res.json(req.user));

// PAPERS ROUTES
app.get('/api/papers', async (req, res) => {
  try {
    const { search, domain, year } = req.query;
    const filters = [];
    const params = [];

    if (search) {
      const value = `%${search}%`;
      filters.push('(LOWER(title) LIKE LOWER(?) OR LOWER(abstract_text) LIKE LOWER(?) OR LOWER(authors) LIKE LOWER(?) OR LOWER(keywords) LIKE LOWER(?))');
      params.push(value, value, value, value);
    }
    if (domain) {
      filters.push('domain = ?');
      params.push(domain);
    }
    if (year) {
      filters.push('YEAR(created_at) = ?');
      params.push(year);
    }

    const where = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
    const [papers] = await db.query(`SELECT * FROM papers ${where} ORDER BY created_at DESC`, params);
    res.json(papers.map(toPaperResponse));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/papers/:id', async (req, res) => {
  try {
    await db.query('UPDATE papers SET views = views + 1 WHERE id = ?', [req.params.id]);
    const [[paper]] = await db.query('SELECT * FROM papers WHERE id = ?', [req.params.id]);
    if (!paper) return res.status(404).json({ error: 'Not found' });
    res.json(toPaperResponse(paper));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/papers', auth, upload.single('file'), async (req, res) => {
  try {
    const { title, abstract, authors, keywords, domain, journal } = req.body;
    if (!title || !abstract || !authors || !domain) {
      return res.status(400).json({ error: 'Required fields missing' });
    }

    const paper = {
      id: uuidv4(),
      title,
      abstract,
      authors,
      keywords: keywords || '',
      domain,
      journal: journal || '',
      fileUrl: req.file ? `/uploads/${req.file.filename}` : null,
      fileName: req.file ? req.file.originalname : null,
      submittedBy: {
        id: req.user.id,
        name: req.user.name,
        role: req.user.role,
        department: req.user.department
      },
      views: 0,
      createdAt: new Date().toISOString()
    };

    await db.query(
      `INSERT INTO papers (
        id, title, abstract_text, authors, keywords, domain, journal, file_url, file_name,
        submitted_by_id, submitted_by_name, submitted_by_role, submitted_by_department,
        views, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        paper.id,
        title,
        abstract,
        authors,
        paper.keywords,
        domain,
        paper.journal,
        paper.fileUrl,
        paper.fileName,
        paper.submittedBy.id,
        paper.submittedBy.name,
        paper.submittedBy.role,
        paper.submittedBy.department,
        0,
        new Date(paper.createdAt)
      ]
    );

    res.json(paper);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/papers/:id', auth, async (req, res) => {
  try {
    const [[paper]] = await db.query('SELECT * FROM papers WHERE id = ?', [req.params.id]);
    if (!paper) return res.status(404).json({ error: 'Not found' });
    if (paper.submitted_by_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Forbidden' });
    }

    if (paper.file_url) {
      const filePath = path.join(__dirname, 'public', paper.file_url);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
    await db.query('DELETE FROM papers WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// STATS ROUTE
app.get('/api/stats', async (req, res) => {
  try {
    const [[paperStats]] = await db.query('SELECT COUNT(*) AS totalPapers, COALESCE(SUM(views), 0) AS totalViews FROM papers');
    const [[userStats]] = await db.query(`
      SELECT
        COUNT(*) AS totalUsers,
        SUM(role = 'faculty') AS faculty,
        SUM(role = 'student') AS students
      FROM users
    `);
    const [domainRows] = await db.query('SELECT domain, COUNT(*) AS count FROM papers GROUP BY domain');
    const domains = {};
    domainRows.forEach(row => {
      domains[row.domain] = row.count;
    });

    res.json({
      totalPapers: paperStats.totalPapers,
      totalUsers: userStats.totalUsers,
      totalViews: Number(paperStats.totalViews),
      domains,
      faculty: Number(userStats.faculty || 0),
      students: Number(userStats.students || 0)
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// USERS (admin)
app.get('/api/users', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const [users] = await db.query('SELECT id, name, email, role, department, joined_at AS joinedAt FROM users ORDER BY joined_at DESC');
    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Server error' });
  }
});

// 404 fallback
app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

initDatabase()
  .then(() => {
    app.listen(PORT, () => console.log(`R&D Portal running at http://localhost:${PORT}`));
  })
  .catch((error) => {
    console.error('Failed to initialize MySQL database:', error.message);
    console.error('Set DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, and DB_NAME if your MySQL settings differ.');
    process.exit(1);
  });
